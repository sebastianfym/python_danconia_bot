Use this token to access the HTTP API:
1943103425:AAEX_S-86jtVO9_rOm4NyckDrFhv7GZL5Tk

Приветствую, вы находитесь в файле с документацией по DanconiaTravelBot.
